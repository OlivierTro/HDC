/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nf;

import java.util.ArrayList;

/**
 *
 * @author ANNELAURE
 */
public class DPI {
    private ArrayList<Sejour> dma= new ArrayList<Sejour>();
    private ArrayList<Sejour> dmMedTech= new ArrayList<Sejour>();
    private ArrayList<Sejour> dmClin= new ArrayList<Sejour>();
    private ArrayList<Sejour> dmAnes= new ArrayList<Sejour>();

}
